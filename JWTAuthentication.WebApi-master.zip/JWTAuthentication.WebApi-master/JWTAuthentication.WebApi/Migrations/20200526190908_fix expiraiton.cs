﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace JWTAuthentication.WebApi.Migrations
{
    public partial class fixexpiraiton : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
